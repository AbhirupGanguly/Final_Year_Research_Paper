import sqlite3
import numpy as np

class Database:
    def __init__(self, path="students.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.cursor = self.conn.cursor()

    def insert_student(self, name, roll, cls, image_url, embedding):
        emb_blob = embedding.tobytes()

        self.cursor.execute("""
        INSERT INTO students (name, roll, class, attention, image_url, embedding)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (name, roll, cls, None, image_url, emb_blob))

        self.conn.commit()

    def insert_teacher(self, name, dept, image_url, embedding):
        emb_blob = embedding.tobytes()

        self.cursor.execute("""
        INSERT INTO teachers (name, dept, image_url, embedding)
        VALUES (?, ?, ?, ?)
        """, (name, dept, image_url, emb_blob))

        self.conn.commit()

    def load_all(self):
        persons = []

        # students
        self.cursor.execute("SELECT * FROM students")
        for r in self.cursor.fetchall():
            emb = np.frombuffer(r[6], dtype=np.float32)
            persons.append({
                "name": r[1],
                "role": "student",
                "roll": r[2],
                "class": r[3],
                "embedding": emb
            })

        # teachers
        self.cursor.execute("SELECT * FROM teachers")
        for r in self.cursor.fetchall():
            emb = np.frombuffer(r[4], dtype=np.float32)
            persons.append({
                "name": r[1],
                "role": "teacher",
                "dept": r[2],
                "embedding": emb
            })

        return persons