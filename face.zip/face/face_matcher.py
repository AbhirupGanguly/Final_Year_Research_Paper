import numpy as np

class FaceMatcher:
    def __init__(self, db):
        self.db = db
        self.refresh()

    def refresh(self):
        self.known = self.db.load_all()

    def match(self, emb):
        best = None
        min_dist = float("inf")

        for p in self.known:
            dist = np.linalg.norm(p["embedding"] - emb)
            THRESHOLD = 0.85   # 🔥 relaxed

            if dist < min_dist and dist < THRESHOLD:
                min_dist = dist
                best = p

        return best