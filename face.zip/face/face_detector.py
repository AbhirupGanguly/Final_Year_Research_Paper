import cv2
from facenet_pytorch import MTCNN
import torch

class FaceDetector:
    def __init__(self):
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.detector = MTCNN(
            keep_all=True,
            min_face_size=40,   # detect smaller faces
            thresholds=[0.6, 0.7, 0.7],
            device=device
        )

    def detect(self, frame):
        try:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            boxes, _ = self.detector.detect(rgb)

            if boxes is None:
                return []

            faces = []
            for box in boxes:
                x1, y1, x2, y2 = map(int, box)

                # avoid invalid crops
                if x2 <= x1 or y2 <= y1:
                    continue

                face = rgb[y1:y2, x1:x2]
                face = cv2.resize(face, (160,160))

                face = torch.tensor(face).permute(2,0,1).float() / 255
                faces.append(face)

            return faces

        except:
            return []