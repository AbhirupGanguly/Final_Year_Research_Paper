from facenet_pytorch import InceptionResnetV1
import torch

class FaceEncoder:
    def __init__(self):
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model = InceptionResnetV1(pretrained='vggface2').eval().to(device)
        self.device = device

    def encode(self, face):
        face = face.unsqueeze(0).to(self.device)
        emb = self.model(face)
        return emb.detach().cpu().numpy()[0]