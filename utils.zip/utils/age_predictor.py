import cv2
import numpy as np

MODEL_MEAN_VALUES = (78.4263377603, 87.7689143744, 114.895847746)

age_list = [
    '(0-2)', '(4-6)', '(8-12)', '(15-20)',
    '(25-32)', '(38-43)', '(48-53)', '(60-100)'
]

class AgePredictor:
    def __init__(self):
        self.net = cv2.dnn.readNetFromCaffe(
            "models/age_deploy.prototxt",
            "models/age_net.caffemodel"
        )

    def predict(self, face_img):
        try:
            blob = cv2.dnn.blobFromImage(
                face_img, 1.0, (227, 227),
                MODEL_MEAN_VALUES, swapRB=False
            )

            self.net.setInput(blob)
            preds = self.net.forward()

            age = age_list[preds[0].argmax()]
            return age

        except:
            return None