import cloudinary
import cloudinary.uploader
from config import CLOUD_NAME, API_KEY, API_SECRET

cloudinary.config(
    cloud_name=CLOUD_NAME,
    api_key=API_KEY,
    api_secret=API_SECRET
)

def upload_image(image_path):
    try:
        result = cloudinary.uploader.upload(image_path)
        return result["secure_url"]
    except Exception as e:
        print("Upload failed:", e)
        return None